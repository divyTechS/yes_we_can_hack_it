<?php
$time1 = time();
sleep(10);
$time2 = time();
$x = $time2 - $time1;
echo "Difference is: " .$x. " seconds";
?>