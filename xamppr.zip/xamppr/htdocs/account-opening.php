<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Opening</title>
    <link rel="stylesheet" href="account-opening.css">
</head>
<body>
    <div class="top"><img src="logo.png" alt="logo img" class="logo"> <h3 class="bank-name">Bank of Nandura Budruk</h3></div>
    <table id="nav-bar" border="4">
        <tr>
            <a href="dashboard.html"><td>Dashboard</td></a>
            <a href="acount-opening.html"><td>Open A/C</td></a>
            <a href="loan.html"><td>Loan</td></a>
            <a href="deposit.html"><td>Deposit</td></a>
        </tr>
    </table>

    <div class="account-opening">
        <h3 class="title">Account Opening Details<br><br><br></h3>
        <div class="details">
        <?php
        echo "Customer Name: ".$_POST["customer-name"]." <br><br><br><br>";
        echo "Address: ".$_POST["address"]." <br><br><br><br>";
        echo "City: ". $_POST["city"]." <br>";
?></div>
        
    </div>
</body>
</html>