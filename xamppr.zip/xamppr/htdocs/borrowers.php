

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrowers Details</title>
    <link rel="stylesheet" href="customerdetails.css">
</head>
<body>
    <div class="top">
        <img src="logo.png" alt="Bank Logo" class="logo">
        <h3 class="bank-name">Bank of Nandura Budruk</h3>
    </div>

    <nav>
        <ul id="nav-bar">
            <li><a href="dashboard.html">Dashboard</a></li>
            <li><a href="account-opening.html">Open A/C</a></li>
            <li><a href="loan.html">Loan</a></li>
            <li><a href="deposit.html">Deposit</a></li>
        </ul>
    </nav>

    <div class="depositor-list">
        <h3 class="title">Borrowers List</h3>
        <div class="table-container">
        <?php
include('conn.php');

$sql = "SELECT customer_name, borrower.loan_number, loan.amount 
FROM borrower
INNER JOIN loan ON borrower.loan_number = loan.loan_number";

$res = mysqli_query($conn, $sql);

// Check if the query was successful
if ($res) {
    // Replace code for table in html page with the following code:
    echo '<table border="1"><tr><th>Name</th><th>Loan No.</th><th>Amount</th><th>Details</th></tr>';
    while ($result = mysqli_fetch_assoc($res)) {
        echo '<tr><td>' . $result['customer_name'] . '</td><td>' .
            $result['loan_number'] . '</td><td>' . $result['amount'] . '</td><td><a href="borrower_detail.php?uname=' . $result['customer_name'] . '">View Details</a></td></tr>';
    }
    echo '</table>';
} else {
    echo "Error executing query: " . mysqli_error($conn);
}
?>

        </div>
    </div>
</body>
</html>
