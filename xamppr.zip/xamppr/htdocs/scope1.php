

<?php
 $x="I am Global"; //global scope
 function _funsum()
 {
 // global $x;
 $y = 5; //local scope 
 echo "Variable y inside the function, $y"; 
 echo "Variable x inside the function: $x"; 
 }
 _funsum();
 Echo "Valued printed outside the function::".$x;
 ?>