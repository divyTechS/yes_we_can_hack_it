<?php
// Include database connection
include('conn.php');

// Check if form data has been posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data from the POST request
    $custname = $_POST['customer-name'];
    $addr = $_POST['address'];
    $city = $_POST['city'];

    // Check for empty fields
    if (empty($custname) || empty($addr) || empty($city)) {
        die('Error: All fields are required.');
    }

    // Prepare the SQL query
    $sql = "INSERT INTO customer (customer_name, address, city) 
            VALUES ('" . mysqli_real_escape_string($conn, $custname) . "', 
                    '" . mysqli_real_escape_string($conn, $addr) . "', 
                    '" . mysqli_real_escape_string($conn, $city) . "')";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        // Redirect to account_confirmed.html after successful insertion
        header('Location: account_confirmed.html');
        exit();  // Stop further script execution
    } else {
        // Output an error message if the insertion fails
        echo "Error: " . mysqli_error($conn);
    }
}
?>
