<center><h3>USING COOKIES</h3></center>
<hr/>
<?php
$cookie_name = "user";
$cookie_value = "PHP Programmer";
if (isset($_COOKIE[$cookie_name]))
echo "<center>Welcome 
<b>".$_COOKIE[$cookie_name]."</b>!</center> <br />";
else
{
setcookie($cookie_name,$cookie_value,time()+30);
echo "<center>Cookie has been set !! try next time!!</center>";
} ?>