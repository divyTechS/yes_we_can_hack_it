

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depositor Details</title>
    <link rel="stylesheet" href="customerdetails.css">
</head>
<body>
    <div class="top">
        <img src="logo.png" alt="Bank Logo" class="logo">
        <h3 class="bank-name">Bank of Nandura Budruk</h3>
    </div>

    <nav>
        <ul id="nav-bar">
            <li><a href="dashboard.html">Dashboard</a></li>
            <li><a href="account-opening.html">Open A/C</a></li>
            <li><a href="loan.html">Loan</a></li>
            <li><a href="deposit.html">Deposit</a></li>
        </ul>
    </nav>

    <div class="depositor-list">
        <h3 class="title">Depositor List</h3>
        <div class="table-container">
        <?php
include('conn.php');
$sql="select customer_name, depositor.account_number, balance from depositor
inner join account on depositor.account_number= account.account_number" ;
$res=mysqli_query($conn, $sql);
//replace code for table in html page with the following code:
echo '<table border="1"><tr><th>Name</th><th>A/C No.</th><th>
Balance</th><th>Details</th></tr>';
while($result=mysqli_fetch_assoc($res))
{
echo '<tr><td>'. $result['customer_name'] . '</td><td>'.
$result['account_number'] . '</td><td>' . $result['balance'] . '</td><td><a
href="depositor_detail.php?uname='. $result['customer_name'] . ' ">View
Details</a></td></tr>';
}
echo '</table>';
?>
        </div>
    </div>
</body>
</html>
