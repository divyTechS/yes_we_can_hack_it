<center><h3>COOKIES EXAMPLE</h3></center>
<hr/>
<?php
$cookie_name = "user";
$cookie_value = "PHP Programmer";
if (isset($_COOKIE["time"])){
$past=$_COOKIE['time'];
$now=time();
$diff=$now-$past;
echo "<center>Welcome 
<b>".$_COOKIE[$cookie_name]."</b>!</center> <br />";
if($diff > 20)
echo "<center><a href='sample1.txt'>click 
here to download file</a>!</center> <br />";