<?php
$DB_USERNAME = "root";
$DB_PASS = "";  // Update if you have a password set in MySQL Workbench
$DB_HOSTNAME = "localhost";  // Or your MySQL server IP (e.g., "127.0.0.1")
$DB_PORT = "3306";  // Change this to the port you're using in MySQL Workbench (default is 3306)
$DB_NAME = "bank_db";  // Your database name

$conn = mysqli_connect($DB_HOSTNAME, $DB_USERNAME, $DB_PASS, $DB_NAME, $DB_PORT);

if (!$conn) {
    die('DATABASE CONNECTION ERROR: ' . mysqli_connect_error());
}
else{
    echo "Database connected successfully";
}
?>
