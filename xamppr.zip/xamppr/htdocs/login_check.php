<?php
session_start();  // Start the session
include('conn.php');  // Include the database connection

// Check if form data exists
if (isset($_POST['user_id']) && isset($_POST['passwd'])) {
    $userid = mysqli_real_escape_string($conn, $_POST['user_id']);
    $pass = mysqli_real_escape_string($conn, $_POST['passwd']);

    // Check if these columns exist in your table (correct as per your table's column names)
    $sql = "SELECT * FROM master_login WHERE user_id='$userid' AND passwd='$pass'";
    $res = mysqli_query($conn, $sql);

    if ($result = mysqli_fetch_assoc($res)) {
        $_SESSION['user_id'] = $result['user_id'];  // Store userid in session
        header('location:bankcustomers.html');  // Redirect to main page
        exit;
    } else {
        header('location:login.html');  // Redirect back to login page if credentials are invalid
        exit;
    }
} else {
    header('location:login.html');  // Redirect if form not submitted properly
    exit;
}
?>
