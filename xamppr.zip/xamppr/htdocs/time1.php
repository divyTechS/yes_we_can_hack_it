<?php
 $current=time();
 echo "The current time is: $current\n"; ?>