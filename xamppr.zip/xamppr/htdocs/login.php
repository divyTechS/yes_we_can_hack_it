<html>
<head> <title>Login</title>
<link rel="stylesheet" href="login.css"> </head>
<body>
    <h1>You have logged in.<br></h1>
    <h2>Login Details</h2>
<div class="details">
    <?php
        echo "Username: ".$_POST["username"]." <br><br><br><br>";
        echo "Password: ".$_POST["password"]." <br><br><br><br>";
        
?>
</div>

</body> </html>