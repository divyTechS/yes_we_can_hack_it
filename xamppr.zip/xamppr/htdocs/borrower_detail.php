

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrowers Details</title>
    <link rel="stylesheet" href="customerdetails.css">
</head>
<body>
    <div class="top">
        <img src="logo.png" alt="Bank Logo" class="logo">
        <h3 class="bank-name">Bank of Nandura Budruk</h3>
    </div>

    <nav>
        <ul id="nav-bar">
            <li><a href="dashboard.html">Dashboard</a></li>
            <li><a href="account-opening.html">Open A/C</a></li>
            <li><a href="loan.html">Loan</a></li>
            <li><a href="deposit.html">Deposit</a></li>
        </ul>
    </nav>
<?php
include('conn.php');
$uname =$_GET['uname'];
$sql="select customer_name, address,
city from customer where
customer_name='$uname'";
$res=mysqli_query($conn,$sql);
$cust_name=''; //blank variable to store information
$addr='';
$city='';
if($result=mysqli_fetch_assoc($res))
{$cust_name=$result['customer_name'];
$addr=$result['address'];
$city=$result['city'];} ?>
<table>
<tr>
<td>Customer Name:</td>
<td><?php echo $cust_name; ?> </td>
<td>Address:</td>
<td><?php echo $addr; ?> </td>
<td>City:</td>
<td><?php echo $city; ?> </td>
</tr>
</table>
</div>
    </div>
</body>
</html>