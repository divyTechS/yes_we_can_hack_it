<html>
<head><title>
Directed From Post Method Example
</title></head>
<body>
echo "Welcome"
<?php
echo $_POST["fname"];
echo " ";
echo $_POST["lname"];
echo ".";
?>
</body></html>